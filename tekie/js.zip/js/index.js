var firstNum = document.querySelector('.integrity');
var secondNum = document.querySelector('.multi-device');
var thirdNum = document.querySelector('.process');
var circles = document.querySelectorAll('.app_round_image');
var menu = document.querySelector(".nav");
var menuItems = menu.querySelectorAll(".nav-item");
var sectionNames = document.querySelectorAll(".section");
var body = document.getElementsByTagName("body");
var copyParents = document.querySelectorAll(".tooltip");
var copy = document.querySelectorAll(".copy");
var copyIcon = document.querySelectorAll(".fa-copy")
var copyConfirm = document.querySelectorAll(".tooltiptext-confirm");
var menuOnOffButton = document.querySelector(".material-icons");
var mobileMenu = document.querySelector(".nav-mobile");
var leanrMoreBtn = document.querySelectorAll(".learn-more");
var counter = 0;

menuOnOffButton.onclick = () => {
  if(counter % 2 == 0) {
    mobileMenu.style.pointerEvents = "all"
    mobileMenu.style.transition = "1s opacity ease"
    mobileMenu.style.opacity = 1;
    menuOnOffButton.innerHTML = "clear";
    leanrMoreBtn.forEach( button => {
      button.style.zIndex = 1;
    })
  } else {
    mobileMenu.style.transition = "1s opacity ease"
    mobileMenu.style.opacity = 0;
    mobileMenu.style.pointerEvents = "none"
    menuOnOffButton.innerHTML = "reorder";
    leanrMoreBtn.forEach( button => {
      button.style.zIndex = 100000000;
    })
  }
  counter++;
}

copyParents.forEach( (copyParent, index) => {
  copyParent.onclick = () => {
    copy[index].select();
    document.execCommand("copy");
    copyConfirm[index].style.visibility = "visible";
    setTimeout(() => {
      copyConfirm[index].style.visibility = "hidden";
    },1000);
  }
})

copyIcon.forEach( icon => {
  icon.onclick = () => {
    icon.style.backgroundColor = "#54f9ba";
    setTimeout(() => {
      icon.style.backgroundColor = "#2a2d2e";
    },1100);
  }
});

window.onload = () => {
  changeActiveFields();
}

circles[0].onmouseover = () => {
  countNumber(firstNum, 84)
}

circles[1].onmouseover = () => {
  countNumber(secondNum, 89)
}

circles[2].onmouseover = () => {
  countNumber(thirdNum, 91)
}

function countNumber(a, n) {
  for (let i=1; i < n + 1 ; i++) {
    setTimeout( function timer(){
        a.innerHTML = i + "%";
    }, i*20 );
  }
}

function changeActiveFields() {
  for (var i = 0; i < menuItems.length; i++) {
    menuItems[i].addEventListener("click", (e) => {
      var current = document.getElementsByClassName("active");
      console.log(current[0]);
      current[0].className = current[0].className.replace("active", "");
      e.target.classList.add("active");
    });
  }
}

body.onscroll = () => {
  sectionNames.forEach ( (item, index) => {

    if ((item.getBoundingClientRect().top < 500) && (item.getBoundingClientRect().top > 0)){
      findActiveField(item);
    }

    if ((item.getBoundingClientRect().top < 500) && (item.getBoundingClientRect().top > 0) && (index != 0)){
      var childrenList = item.children;
      item.classList.add("appearUp");
      addClassToChildren(childrenList, "appearUp");
      changeOpacity(item);
    }
  })
}

function findActiveField (fieldName) {
  for (var i = 0; i < menuItems.length; i++) {
    activeFieldName = fieldName.children[0].attributes[0].value.toLowerCase()
    if(activeFieldName == menuItems[i].childNodes[0].nodeValue.toLowerCase()){
      menuItems[i].classList.add("active");
    } else {
      menuItems[i].classList.remove("active");
    }
  }
}

function addClassToChildren(e, choosenclass) {
  for (var i = 0; i < e.length; i++) {
    e[i].classList.add(choosenclass);
    var newChildren = e[i].children;
    addClassToChildren(newChildren, choosenclass);
  }
}

function changeOpacity(e) {
  e.style.opacity = 1;
  removeAnimation(e,("appearUp", "fadeIn"));
}

function removeAnimation(e, choosenclass) {
  e.classList.remove(choosenclass);
}
